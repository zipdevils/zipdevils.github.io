<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // Ensure JSON response

    // Check if both files are uploaded
    if (!isset($_FILES['password_file']) || !isset($_FILES['zip_file'])) {
        echo json_encode(["error" => "Please upload both a password file and a zip file."]);
        exit;
    }

    // Handle password file upload
    $passwordFile = $_FILES['password_file']['tmp_name'];
    if (!file_exists($passwordFile)) {
        echo json_encode(["error" => "Password file upload failed."]);
        exit;
    }

    // Handle zip file upload
    $zipFile = $_FILES['zip_file']['tmp_name'];
    if (!file_exists($zipFile)) {
        echo json_encode(["error" => "ZIP file upload failed."]);
        exit;
    }

    // Set extraction path
    $extractToPath = "files/";

    // Ensure the extraction folder exists
    if (!is_dir($extractToPath)) {
        mkdir($extractToPath, 0777, true);
    }

    // Function to try unlocking the zip file
    function tryPassword($zipFilePath, $password, $extractToPath) {
        $zip = new ZipArchive();
        if ($zip->open($zipFilePath) === true) {
            if ($zip->setPassword($password)) {
                if ($zip->extractTo($extractToPath)) {
                    $zip->close();
                    return true; // Successfully unlocked
                }
            }
            $zip->close();
        }
        return false; // Failed to unlock
    }

    // Open the password file for reading
    $handle = fopen($passwordFile, 'r');
    if (!$handle) {
        echo json_encode(["error" => "Failed to open the password file."]);
        exit;
    }

    // Process the file line by line
    while (($password = fgets($handle)) !== false) {
        $password = trim($password); // Remove extra whitespace

        // Send real-time progress update
        echo json_encode(["status" => "trying", "password" => $password]);
        echo "\n"; // Ensure newline for chunked streaming
        ob_flush();
        flush();

        if (tryPassword($zipFile, $password, $extractToPath)) {
            fclose($handle);

            // Send success response
            echo json_encode([
                "status" => "success",
                "password" => $password,
                "message" => "Password found! Files extracted to: $extractToPath"
            ]);
            echo "\n"; // Ensure newline for streaming
            exit;
        }
    }

    // Close the password file after reading
    fclose($handle);

    // If no password matched
    echo json_encode(["status" => "failed", "message" => "No password matched."]);
    echo "\n";
    exit;
}
?>
