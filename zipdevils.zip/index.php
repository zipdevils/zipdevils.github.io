<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zipdevil Password Unlocker</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url("hacker.jpg");
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        .container {
            width: 400px;
            text-align: center;
        }

        .title {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        input[type="file"] {
            background-color: #1e1e1e;
            color: #ffffff;
            border: 1px solid #333;
            padding: 10px;
            width: 100%;
        }

        button {
            background-color: #0066cc;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0052a3;
        }

        .output {
            margin-top: 20px;
            background-color: #1e1e1e;
            color:lime;
            padding: 10px;
            border: 1px solid #333;
            max-height: 300px;
            overflow-y: auto;
        }

        .success {
            color: blue;
        }

        .error {
            color: #f44336;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">Zipdevil zip cracking tool</div>
        <form id="unlocker-form">
            <div class="form-group">
                <label for="zip_file">Select ZIP File:</label>
                <input type="file" name="zip_file" id="zip_file" accept=".zip" required>
            </div>
            <div class="form-group">
                <label for="password_file">Select Password File (passwords.txt):</label>
                <input type="file" name="password_file" id="password_file" accept=".txt" required>
            </div>
            <button type="submit">Start Unlocking</button>
        </form>
        <div class="output" id="output">
            <p>Progress will appear here...</p>
        </div>
    </div>

    <script>
        document.getElementById('unlocker-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData();
            const zipFile = document.getElementById('zip_file').files[0];
            const passwordFile = document.getElementById('password_file').files[0];

            if (!zipFile || !passwordFile) {
                alert("Please select both files.");
                return;
            }

            formData.append('zip_file', zipFile);
            formData.append('password_file', passwordFile);

            const output = document.getElementById('output');
            output.innerHTML = '<p>Starting...</p>';

            const response = await fetch('unlocker.php', {
                method: 'POST',
                body: formData,
            });

            const reader = response.body.getReader();
            const decoder = new TextDecoder();

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value).trim();
                const lines = chunk.split("\n");

                lines.forEach((line) => {
                    try {
                        const data = JSON.parse(line);

                        if (data.status === "trying") {
                            output.innerHTML += `<p>Trying password: ${data.password}</p>`;
                        } else if (data.status === "success") {
                            output.innerHTML += `<p class="success">Password found: ${data.password}</p>`;
                            output.innerHTML += `<p class="success">${data.message}</p>`;
                        } else if (data.status === "failed") {
                            output.innerHTML += `<p class="error">${data.message}</p>`;
                        }
                    } catch (err) {
                        console.error("Error parsing JSON chunk:", line);
                    }
                });

                output.scrollTop = output.scrollHeight; // Auto-scroll
            }
        });
    </script>
</body>
</html>
